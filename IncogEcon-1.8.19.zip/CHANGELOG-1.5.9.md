# Incog-Shop 1.5.9

- Added My Auctions GUI in /ah.
- Players can cancel their own Buy It Now listings and auctions with no bids from the GUI.
- Auctions with bids remain locked from cancellation.
- Cancelled items go to the Auction House claim queue.
- Added AH_CANCEL audit logging.
