# Incog-Shop 1.7.2

- Fixed item-browser Back button: any built-in category page now returns to that category's Subcategories screen.
- `/sell` now sells eligible contents automatically when the GUI is closed; the Sell button still works immediately.
- Cancel still safely returns items; overflow is moved to `/stash`.
- Added persistent automatic market restocking every 72 hours.
- Only BUY_SELL items below 100 stock are restocked, to a random stock value from 500 through 1000.
- Restock schedule persists in `market.yml` and does not reset with server restarts.
- Market search now opens a sign editor instead of requiring chat input.
- Auction House Claims button now opens a paginated claims GUI with individual Claim and Claim All.
- Added `/stash` overflow storage with a paginated GUI.
- Stash supports individual claiming, Claim All, and Sell All Eligible.
- Auction/order/sell-GUI overflow now goes to stash instead of being lost or dropped.
