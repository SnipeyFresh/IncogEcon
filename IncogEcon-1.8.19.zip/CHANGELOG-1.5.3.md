# Incog-Shop 1.5.3

- Auction listings now open a dedicated detail GUI.
- Auction bids can be placed directly through GUI buttons.
- Added Minimum Bid, +10%, +25%, and Custom Bid controls.
- Custom Bid accepts shorthand such as 10k, 2.5m, and 1b through a short chat prompt.
- Buy It Now listings now use a dedicated GUI purchase button.
- `/ah bid` remains available as an optional fallback.
