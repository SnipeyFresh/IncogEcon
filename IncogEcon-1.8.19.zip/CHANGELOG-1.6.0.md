# Incog-Shop 1.6.0

- Added **All Market Orders** browser directly to `/market`.
- Browse All Orders, Buy Orders only, or Sell Orders only.
- Clicking an order opens that material's normal Order Book.
- Added pagination, My Orders access, and claim access from the global browser.
- Added Discord price-check startup diagnostics for incorrectly-indented YAML config.
