# Incog-Shop 1.6.1

- Fixed Java compile error in the global market-order browser.
- Normalized the order filter into an effectively-final variable before stream/lambda use.
- No data or behavior changes beyond the compile fix.
