# Incog-Shop 1.8.8

- Fixed physical player-shop stocking: owners/admins can now sneak-right-click a registered shop to explicitly open its backing chest/barrel inventory.
- Added configurable 10-block player-shop protection with `player-shops.protection-radius`.
- Other players cannot break or place blocks inside a shop's protection radius.
- The shop owner may still build around their own shop, while `incogshop.playershop.bypass` bypasses all shop-region protection.
- Overlapping shop regions are respected: owning one shop does not bypass another owner's protection.
- Explosions and piston movement no longer damage/move blocks inside protected shop regions.
- Registered shop containers themselves still require `/pshop remove` before they can be broken.
