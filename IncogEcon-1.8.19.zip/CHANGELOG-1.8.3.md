# Incog-Shop 1.8.3

- Fixed **Back to Subcategories** appearing in the top-left of the item browser.
- Added a one-time migration that moves legacy `items.back` positions outside the navbar back to slot 46.
- Fixed item-control collision resolution so collisions prefer the normal bottom navigation row (45-53) instead of jumping to slot 0.
- Preserves GUI Layout Designer customization after the migration; admins can still deliberately move the Back control later.
- Updated Layout Designer wording to make the Back control's purpose clearer.
