# Incog-Shop 1.8.5

## Crash / performance hotfix
- Moved YAML file writes onto a dedicated single-thread Incog-Shop I/O worker.
- YAML snapshots are still created on the server thread, but blocking filesystem writes no longer happen there.
- All async writes use temp-file replacement to reduce corruption risk.
- Autosaves are staggered across the autosave interval instead of writing every Incog-Shop data file on the same tick.
- `audit.log` writes are queued off the server thread.
- Price-history capture now opens/appends the history file once per capture batch instead of once per changed material.
- Hourly price-history rewrites are queued to the I/O worker.
- `/marketadmin reload` waits for pending writes before reloading files.
- Server shutdown flushes pending I/O before Incog-Shop finishes disabling.

## DiscordSRV integration
- Replaced the raw reflected JDA event listener with DiscordSRV's supported API event subscription.
- Incoming Discord commands are handed back to the Minecraft server thread before reading market/history state.
- A blank `discord-price-check.channel-id` now falls back to DiscordSRV's main linked text channel.
- Added `/marketadmin discord status`.
- Added `/marketadmin discord test`.
- More useful Discord integration startup/status logging.

## Included previous fixes
- XP Vault now loads persisted UUID balances on startup/reload.
- Stash stacking remains enabled.
- Centered subcategories and GUI layout migrations remain included.
- Item-browser Back to Subcategories bottom-navbar fix remains included.
