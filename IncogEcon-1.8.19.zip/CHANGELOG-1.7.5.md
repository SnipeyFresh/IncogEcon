# Incog-Shop 1.7.5

- Added persistent XP Vault.
- `/xpvault` (alias `/xpbank`) opens a GUI.
- GUI supports Deposit 25%, Deposit 50%, Deposit All, Withdraw 25%, Withdraw 50%, Withdraw All.
- Direct commands:
  - `/xpvault deposit <amount|all>`
  - `/xpvault withdraw <amount|all>`
- XP is stored as raw experience points, not just Minecraft levels.
- XP Vault balances persist in `xp-vault.yml`.
- Permission: `incogshop.xpvault` (default true).
