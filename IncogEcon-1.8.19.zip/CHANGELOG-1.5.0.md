# Incog-Shop 1.5.0

- Vault + ExcellentEconomy integration; Vault is the default source of truth for balances.
- Auction House with Auction and Buy It Now modes, escrowed bidding, expiry settlement, and claims.
- `/sell` bulk market-selling GUI.
- Netherite items added to the global market; Ancient Debris remains excluded.
- One-time 1,000-stock bootstrap for every global-market material.
- Shorthand prices such as 10k, 2.5m, 5m, 1.2b and 1t.
- Player Buy Orders and Sell Orders with price-time priority, escrow, automatic matching, cancellation, and item claims.
- Complete Incog-Shop/SnipeyFresh branding and `incogshop.*` permission namespace.
