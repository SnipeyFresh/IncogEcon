# Incog-Shop 1.8.6

- Fixed Maven compilation of `DiscordPriceBridge`.
- DiscordSRV 1.30.5 shades and relocates JDA, so Incog-Shop now imports
  `github.scarsz.discordsrv.dependencies.jda.api.entities.TextChannel`.
- No separate JDA dependency is added to Incog-Shop.
- Preserves the 1.8.5 performance/crash hotfixes, DiscordSRV event-bus integration,
  XP Vault persistence, stash fixes, and GUI fixes.
