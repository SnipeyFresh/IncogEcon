# Incog-Shop 1.7.8

- Rebuilt gameplay stash overflow around Paper's `PlayerAttemptPickupItemEvent`.
- Uses Paper's own `getRemaining()` value to know exactly how many items cannot fit.
- Fully-full inventories now stash the entire attempted pickup.
- Partially-full inventories receive what fits and stash only the remainder.
- Removed the old direct block-break and mob-death interception registration to prevent duplicate/conflicting item handling.
- Applies to normal ground pickups, including mined blocks/ores, mob drops, thrown items, and other item entities.
- Existing Incog-Shop delivery overflow continues to use the same persistent stash.
