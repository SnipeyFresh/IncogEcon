# IncogEcon 1.8.18

- Reverted the two recent Auto Restock control remaps from 1.8.16 and 1.8.17.
- Admin Studio -> Item Organizer is back to:
  - Left-click = Move/change category
  - Right-click = Cycle market mode
  - Middle-click = Toggle Auto Restock
- The actual Admin Market remains unchanged:
  - Middle-click = Reset Price
  - Q = Change Category
  - Ctrl+Q = Set Exact Stock
- No market data or Auto Restock settings are reset.
