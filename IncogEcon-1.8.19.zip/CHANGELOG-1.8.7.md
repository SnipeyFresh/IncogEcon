# Incog-Shop 1.8.7

- Added exact stock editing directly from the admin market GUI.
- Double-click a market item in admin mode to open a virtual sign and enter the exact stock amount.
- Supports whole-number shorthand such as `2.5k` -> `2500`, plus `0` to empty the stock.
- Exact stock editing works in both built-in and custom category item browsers.
- Requires `incogshop.admin.stock`.
- Stock values now consistently respect `market.maximum-stock-per-material`.
- Preserves all 1.8.6 Discord, performance, XP Vault, stash, and GUI fixes.
