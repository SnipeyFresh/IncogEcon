# Incog-Shop 1.7.4

- Reworked market search into ranked smart search.
- Exact matches rank first, followed by prefixes, word/partial matches, aliases, and fuzzy typo matches.
- Spaces, underscores, hyphens, and capitalization are normalized automatically.
- Multi-word partial searches work, e.g. `red wo` and `diamond sw`.
- Minor typos are tolerated, e.g. `diamnd sword`.
- Added common aliases such as `gap`, `gapple`, `xp bottle`, `rocket`, `totem`, `cobble`, and shortened pickaxe names.
- Search still uses the sign input GUI from 1.7.2+.
