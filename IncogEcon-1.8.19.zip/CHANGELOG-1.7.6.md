# Incog-Shop 1.7.6

- `/marketadmin gui` now includes a Market Setup GUI.
- Admins can create custom categories entirely through GUI/sign input.
- Admins can create real custom subcategories under custom categories.
- Custom categories with subcategories now show a subcategory-selection screen to players.
- Hold an item while creating a category/subcategory to use that material as its icon; CHEST is the fallback.
- Shift-click a custom category in Market Setup to assign the held item to that category.
- Click a custom subcategory in Market Setup to assign the held item directly to that subcategory.
- Added Quick Add Held Item and Add Held Item GUI actions.
- Adding a held vanilla item uses its Incog-Shop default base price and BUY_SELL mode, then opens placement controls.
- Existing `/marketadmin createcategory`, `setcategory`, and `additem` commands remain available as backup/admin automation tools.
