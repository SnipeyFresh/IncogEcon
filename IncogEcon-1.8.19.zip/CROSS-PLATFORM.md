# Cross-Platform Player Support

IncogEcon 1.8.19 is designed so normal player features do not require Java-only inventory gestures.

## Player UI rules

- One visible GUI button = one action.
- No player feature requires distinguishing left-click from right-click inside an inventory.
- No player feature requires middle-click, Q/drop, Ctrl+Q, offhand/F, or shift-click.
- Text and numeric input used by player features is entered through normal chat prompts.
- Admin-only GUI shortcuts are intentionally unchanged.

## Bazaar

The item page provides separate buttons for:

- Buy 1
- Buy one material stack
- Custom instant-buy amount
- Sell 1
- Sell up to one material stack
- Create Buy Order
- Create Sell Order
- Browse orders / claims

Custom buy amounts and order amount/price entry use chat.

## Auction House

- Listing price uses chat input.
- Duration uses four separate buttons: -24h, -1h, +1h, +24h.
- Custom bid uses chat input.
- All other actions use dedicated GUI buttons.

## Player Trading

- Inventory items are added by tapping/clicking them.
- Money offer uses chat input.
- Confirm and cancel have dedicated GUI buttons.
- No left/right-click distinction is required.

## Player Shops

- Buying 1 and buying a stack have separate buttons.
- Shop owners can press **Open Shop Stock** in the shop GUI.
- `/pshop stock` is available as a fallback while looking at an owned shop.
- Sneak-interact stocking remains an optional shortcut, not a requirement.

## Other player systems

Sell GUI, Stash, XP Vault, claims, order management, and Sell Wands use ordinary inventory buttons or standard Minecraft block interaction.

## Geyser/Floodgate

IncogEcon does not directly depend on Geyser or Floodgate. Install and configure those separately for Bedrock connectivity.

Custom Java resource-pack item models from IncogEcon or other plugins may require matching Bedrock/Geyser custom-item mappings for Bedrock clients to display them correctly. This is a client/protocol presentation concern; IncogEcon's server-side item storage/trading logic still uses the ItemStack supplied by the server.
