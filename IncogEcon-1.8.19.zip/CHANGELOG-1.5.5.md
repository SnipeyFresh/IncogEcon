# Incog-Shop 1.5.5

- Added a global Infinite Stock toggle for the entire server market.
- When enabled, players can buy globally tradable items even at 0 stored stock.
- Infinite-stock purchases do not reduce stored market stock.
- Player selling still adds items to stored stock.
- When disabled, purchases again require and consume actual stored stock.
- Added admin GUI toggle.
- Added `/marketadmin infinitestock on|off|toggle|status`.
