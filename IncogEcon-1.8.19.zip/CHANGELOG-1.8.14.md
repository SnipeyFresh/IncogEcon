# Incog-Shop 1.8.14

- Added a custom exact quantity option to Bazaar instant buying.
- Bazaar item pages now include a **Custom Buy Amount** button next to Buy Instantly.
- Clicking it opens a virtual sign that accepts positive whole numbers and shorthand such as `128` or `2k`.
- Custom instant buys are all-or-nothing: insufficient stock, inventory space, or balance cancels the purchase instead of partially filling it.
- Regular instant buy controls remain unchanged: click buys 1 and shift-click buys up to one stack.
- Improved plain market purchase delivery by splitting large purchases into legal Minecraft stack sizes.
- Preserves all 1.8.13 trading, Bazaar, player-shop, Sell Wand, XP Vault, Discord, restock, and admin features.
