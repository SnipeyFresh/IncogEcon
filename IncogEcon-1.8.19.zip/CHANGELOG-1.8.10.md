# Incog-Shop 1.8.10

- Simplified Sell Wand command to `/sellwand`.
- Running `/sellwand` gives the executing player one genuine Sell Wand.
- Removed the old `give <player> [amount]` arguments and tab completion.
- Console cannot use `/sellwand` because the item is given directly to the executing player.
- Permission remains `incogshop.sellwand.give` (default: op).
