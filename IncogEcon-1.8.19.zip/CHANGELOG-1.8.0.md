# Incog-Shop 1.8.0

- Added a **Create Listing** button directly inside `/ah`.
- New GUI supports both Auction and Buy It Now listing modes.
- The exact stack in the player's main hand is previewed before listing.
- Price entry uses a virtual sign and supports shorthand such as `10k`, `2.5m`, and `1b`.
- Duration can be adjusted by 1-hour or 24-hour increments.
- Admin permanent-listing mode is respected and shown as `Never Expires`.
- The GUI shows listing fee, balance, selected price, duration, and mode before confirmation.
- Item is only removed after AuctionManager successfully creates the listing.
- Existing `/ah sell auction ...` and `/ah sell bin ...` commands remain available.
