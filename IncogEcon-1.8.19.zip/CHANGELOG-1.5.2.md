# Incog-Shop 1.5.2

- VAULT mode now uses Vault's currently registered Economy provider.
- Removed the ExcellentEconomy-specific provider requirement.
- Removed Incog-Shop `/balance`, `/bal`, `/money`, and `/pay` command registrations to avoid collisions with EssentialsX.
- Market, Auction House, physical shops, orders, and admin money operations still use the active Vault economy provider.
