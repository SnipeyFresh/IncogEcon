# Incog-Shop 1.8.12

- Replaced unreliable admin double-click stock editing with **Ctrl+Q**.
  - Ctrl+Q on a market item: set exact stock using virtual sign input.
  - Q on a market item: change category.
- Added per-item automatic restock control.
  - Admin Studio -> Organize Market Items.
  - Middle-click an item to toggle Auto Restock ON/OFF.
  - State is stored in `market.yml` as `<MATERIAL>.auto-restock`.
  - Disabled items are skipped by the scheduled restock.
- Removed Ancient Debris from the hard market blacklist.
- Ancient Debris is automatically categorized under Ores & Minerals -> Ores & Raw Materials.
- Ancient Debris default base price is 1400, matching Netherite Scrap.
- Existing market data remains compatible; missing `auto-restock` values default to ON.
