# Incog-Shop 1.5.4

- Global market selling ignores ordinary durability damage.
- Used tools, weapons, armor, shields, elytra, fishing rods, etc. can be sold at any durability.
- `/sell` uses the same durability-tolerant eligibility rules.
- Market Sell Orders accept ordinary damaged items.
- Names, lore, enchantments, custom model/data, attributes, unbreakable state, and other meaningful custom metadata are still protected.
- Physical player shops and Auction House listings still preserve exact ItemStacks.
