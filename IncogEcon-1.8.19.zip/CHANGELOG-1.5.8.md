# Incog-Shop 1.5.8

- Fixed Discord price-check compilation by removing direct JDA imports.
- Discord integration now crosses the DiscordSRV/JDA boundary through reflection.
- Incog-Shop no longer depends on a specific JDA artifact/version at compile time.
- This avoids JDA version/classloader conflicts with DiscordSRV.
- Discord price output is sent as clean formatted text rather than a JDA EmbedBuilder.
