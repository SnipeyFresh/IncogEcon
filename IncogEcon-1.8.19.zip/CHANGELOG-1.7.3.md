# Incog-Shop 1.7.3

- `/stash` now catches overflow from player-broken block/ore drops.
- `/stash` now catches overflow from mobs directly killed by a player.
- Gameplay drops are inserted into inventory first; only items that do not fit are stashed.
- Existing shop/order/auction/sell overflow still uses `/stash`.
- Fixed Back-to-Subcategories handling by resolving GUI control slots uniquely.
- Market item slots can no longer overlap Back/Search/page-navigation control slots.
