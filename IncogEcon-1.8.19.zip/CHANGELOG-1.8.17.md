# IncogEcon 1.8.17

- Fixed another Auto Restock control conflict.
- Admin Market keeps:
  - Middle-click = Reset Price
  - Q = Change Category
  - Ctrl+Q = Set Exact Stock
- Admin Studio -> Item Organizer now uses:
  - Left-click = Move/change category
  - Right-click = Cycle market mode
  - Shift + Right-click = Toggle Auto Restock
- Updated all affected GUI lore.
