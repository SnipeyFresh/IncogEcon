# Incog-Shop 1.8.2

- Fixed built-in subcategory buttons appearing left-aligned when upgrading from older GUI layouts.
- Added a one-time `gui-layout.yml` migration that removes only legacy `subcategories.sub:*` positions while preserving navigation/control positions and other screen layouts.
- Reworked `centeredSlots()` to create genuinely symmetrical rows around the center column.
- Even-sized rows now leave a center gap where appropriate: 2 items use columns 3/5, 4 items use 2/3/5/6, and 6 items use 1/2/3/5/6/7.
- Larger sets are balanced across rows instead of filling 7 on the first row and leaving a single button on the next row.
