# Incog-Shop 1.7.9

- Stash items now automatically stack with identical items.
- Uses Bukkit `ItemStack#isSimilar`, so metadata/NBT/enchantments must match before stacks merge.
- Stacks respect the item's normal maximum stack size.
- Excess quantities are split into normal full stacks instead of one oversized stack.
- Existing `stash.yml` contents are compacted automatically when the plugin loads.
- Claiming and Sell All operations re-compact the remaining stash afterwards.
