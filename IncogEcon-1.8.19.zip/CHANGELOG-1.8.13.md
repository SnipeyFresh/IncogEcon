# Incog-Shop 1.8.13

- Added secure player-to-player trading with items and money.
- `/trade <player>` sends a trade request.
- `/trade accept [player]`, `/trade deny [player]`, and `/trade cancel` manage requests/sessions.
- Shared 54-slot trade GUI with 9 item offer slots per player.
- Clicking items in the player inventory moves the entire stack into escrow.
- Clicking your own offered item returns it.
- Exact money offers use a virtual sign and support shorthand such as `25k` and `2.5m`.
- Both players must confirm the final offer. Any item or money change resets both confirmations.
- Money balances are revalidated immediately before completion.
- Trade items are returned on cancel, inventory close, disconnect, plugin reload, or shutdown.
- Inventory overflow is routed to `/stash`.
- Trade completions/cancellations are written to the existing audit log.
- New permission: `incogshop.trade` (default true).
- New config section: `trading`.
- Preserves all 1.8.12 Bazaar, restock, Ancient Debris, Sell Wand, player-shop, Discord, XP Vault, and GUI fixes.
