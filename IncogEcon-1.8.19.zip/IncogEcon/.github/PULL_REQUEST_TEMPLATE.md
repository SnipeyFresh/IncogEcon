## Summary

Describe the change.

## Testing

- [ ] `mvn clean package` passes on Java 25+
- [ ] Existing data/config compatibility considered
- [ ] Permissions/commands documentation updated if needed
- [ ] Player-facing changes tested/considered for Java + Bedrock/Geyser interaction

## Migration

Does this require config or persistent-data migration? If yes, explain it here.
