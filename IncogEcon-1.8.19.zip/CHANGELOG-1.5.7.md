# Incog-Shop 1.5.7

- Added optional DiscordSRV integration for market price checks.
- Configure one Discord text channel by channel ID.
- `!price <item>` shows current buy/sell price, base price, percent vs starting/base price, stock, and default historical windows.
- `!price <item> <window>` supports focused windows such as 7h, 24h, or 7d.
- `!pricehelp` displays Discord usage.
- Added rolling 5-minute-resolution price history with configurable retention (30 days by default).
- History is written only when an item's price changes, keeping the file substantially smaller than full snapshots.
- Existing market/economy/auction/shop data formats are unchanged.
