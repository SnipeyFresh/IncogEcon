# IncogEcon 1.8.16

- Fixed the Auto Restock control conflict.
- Admin Market keeps **Middle-click = Reset Price**.
- Admin Studio -> Item Organizer now uses **Q / Drop = Toggle Auto Restock**.
- Ctrl+Q in the Item Organizer also toggles Auto Restock.
- Updated GUI lore so the correct controls are shown.
