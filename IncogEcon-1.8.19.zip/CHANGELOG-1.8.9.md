# Incog-Shop 1.8.9

- Added command-only Sell Wands.
- `/sellwand give <player> [amount]` gives a genuine PDC-tagged wand; renamed lookalikes do not work.
- Right-clicking a Bukkit storage `Container` sells every eligible stack to the server market.
- Unsellable/custom items and stock that would exceed the market maximum stay in the container.
- Sell Wands use the normal dynamic server sell price, transaction fee, market stock, demand pressure, Vault payout, and audit logging.
- Registered player shops cannot be wand-drained by other players.
- The 10-block player-shop protection radius also blocks Sell Wand use on nearby protected containers.
- Added `incogshop.sellwand.use` (default true) and `incogshop.sellwand.give` (default op).
- Added configurable Sell Wand material/name/lore in `config.yml`.
