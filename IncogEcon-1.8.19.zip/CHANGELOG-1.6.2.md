# Incog-Shop 1.6.2

- Fixed `/ah` incorrectly requiring the removed `incogshop.balance` permission.
- `/ah` now correctly requires only `incogshop.auction`.
- Normal player permission defaults remain enabled.
- No data format or economy changes.
