# IncogEcon 1.8.15

- Renamed the plugin from **Incog-Shop** to **IncogEcon**.
- Bukkit/Paper plugin name is now `IncogEcon`.
- Maven artifact is now `incog-econ`.
- Built JAR is now `IncogEcon-1.8.15.jar`.
- Updated GUI titles, messages, Discord text, logging, and default chat prefix to IncogEcon.
- Kept the Java package (`com.snipeyfresh.incogshop`) and `incogshop.*` permission nodes unchanged for compatibility.
- Added a one-time startup migration that copies missing data from `plugins/Incog-Shop/`
  into `plugins/IncogEcon/`, leaving the old folder untouched as a backup.
- Preserves all 1.8.14 features and data formats.
