# IncogEcon 1.8.19

## Cross-platform player UI

This release makes all normal player-facing IncogEcon workflows usable without Java-only inventory gestures.

- Bazaar item pages now use dedicated **Buy 1**, **Buy Stack**, **Custom Buy**, **Sell 1**, and **Sell Stack** buttons. Shift-click is no longer required for stack trades.
- Custom instant-buy amounts now use a chat prompt instead of a virtual sign.
- Player market search now uses a chat prompt. Admin search/sign behavior is unchanged.
- Auction listing prices now use chat input instead of a virtual sign.
- Auction duration now uses four dedicated buttons: -24h, -1h, +1h, +24h. Left/right/shift click distinctions are no longer required.
- Trade money offers now use chat input instead of a virtual sign.
- Player-shop owners now get an **Open Shop Stock** GUI button.
- Added `/pshop stock` as a universal fallback for opening a shop's backing container.
- Existing sneak-right-click shop stocking remains as an optional shortcut.
- No Geyser/Floodgate API dependency was added; the same player GUI paths work for Java and Bedrock clients.
- Admin-only controls were intentionally left unchanged.
