# Incog-Shop 1.5.1

- Added explicit Vault economy-provider selection.
- Default preferred provider is `ExcellentEconomy`.
- Incog-Shop will no longer silently use EssentialsX Economy when ExcellentEconomy is configured.
- Startup logs list the selected provider, or all providers Vault currently exposes if the preferred one is unavailable.
- Vault is now a hard plugin dependency in VAULT builds so its API is loaded first.
