# Incog-Shop 1.8.1 — GUI Redesign

## Market polish
- Rebuilt the main Market category screen around centered, symmetrical category placement.
- Built-in and custom categories now share one centered layout calculation instead of competing for separate slot ranges.
- Added cleaner black/accent framing and consistent visual hierarchy.
- Player navigation is centered around Search, Orders, Balance, and Market Guide.
- Admin browse mode uses centered Admin Studio, Infinite Stock, and Layout controls.
- Fixed Back button labeling so category-wide item views correctly say **Subcategories** when that is the destination.
- Updated remaining search hints to describe the sign-based search flow.

## Admin Studio
- `/marketadmin gui` now opens a dedicated Admin Studio dashboard.
- Added large centered actions for Categories & Sections, Item Organizer, Add Held Item, GUI Layout Designer, Admin Market, and Infinite Stock.
- Category management is now paginated and visually centered.
- Left-click a category to manage its subcategories.
- Shift-click a category to assign the held item.
- Right-click a category to remove it through a confirmation GUI.
- Subcategories can also be created, assigned, and removed directly from the GUI.
- Removing a category never deletes market items; they return to automatic built-in placement.
- Removing a subcategory keeps its items in the parent custom category.

## Item Organizer
- Added a paginated visual organizer for every market material.
- Each item shows its current category/subcategory, market mode, and stock.
- Left-click an item to move it.
- Right-click an item to cycle Buy & Sell → Sell Only → Disabled.
- The destination picker supports built-in categories, custom categories, and custom subcategories.
- Reset-to-Automatic clears both built-in and custom placement overrides.
- Moving an item from a custom category into a built-in category now clears the stale custom assignment first.

## Layout Designer
- Redesigned the layout editor into a centered screen selector.
- Added a one-click **Reset This Layout** action for each screen.
- Updated centered default control positions for categories and subcategories.
- Layout changes still save automatically to `gui-layout.yml`.
