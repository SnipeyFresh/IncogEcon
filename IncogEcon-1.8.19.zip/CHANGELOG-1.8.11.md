# Incog-Shop 1.8.11

- Reworked the player market into a Bazaar-style item flow.
- Clicking any market item now opens that item's dedicated Bazaar page instead of instantly buying/selling it.
- Added **Buy Instantly** and **Sell Instantly** actions to the item page.
  - Click = 1 item.
  - Shift-click = up to one full stack.
- Kept **Create Buy Order** and **Create Sell Order** on the same item page.
- Shows the top player Buy Orders and Sell Orders for that material.
- Shows server stock, instant prices, best bid/ask, balance, and eligible inventory count.
- While any player Bazaar screen is open, clicking a tradable item in the player's own inventory jumps directly to that item's Bazaar page.
- The inventory shortcut also works from the item page, global order browser, and My Orders screen.
- Sell Wands are excluded from the inventory-item shortcut so the special wand cannot be mistaken for its base material.
- Admin market controls remain unchanged.
- Includes all fixes/features from 1.8.10 and earlier.
