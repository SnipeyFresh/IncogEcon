# Incog-Shop 1.7.7

- Fixed the stash overflow system not catching normal world item pickups.
- Mob drops, mined block drops, and other dropped Item entities now send only the portion that cannot fit in the player's inventory to `/stash`.
- Partial-stack pickups are handled correctly: the amount that fits goes into the inventory and only the remainder is stashed.
- Shop/plugin deliveries continue to use the existing `deliverOrStash` path.
- Players receive an action-bar notice when overflow is sent to the stash.
