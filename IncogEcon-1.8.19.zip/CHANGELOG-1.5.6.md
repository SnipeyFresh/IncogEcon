# Incog-Shop 1.5.6

- Fixed the missing `isInfiniteStockEnabled()` and `setInfiniteStockEnabled(...)` methods that caused 1.5.5 to fail compilation.
- Fixed the actual market purchase path so Infinite Stock bypasses stored-stock limits.
- Infinite Stock purchases do not reduce stored market stock.
- Selling still increases stored stock normally.
- When Infinite Stock is disabled, purchases require and consume actual stored stock.
