# Incog-Shop 1.7.0

## Admin GUI customization
- Added `/marketadmin layout` and an Admin Market button for a persistent GUI Layout Editor.
- Category buttons and key main-market controls can be moved to custom inventory slots.
- Layout is saved in `gui-layout.yml`.

## Custom categories
- Added persistent custom categories in `custom-categories.yml`.
- `/marketadmin createcategory <id> <icon-material> <display name...>`
- `/marketadmin deletecategory <id>`
- `/marketadmin setcategory <material> <custom-category-id|auto>`
- Custom categories appear on the main `/market` category GUI and can be positioned with the Layout Editor.
- Items assigned to a custom category are removed from their built-in category view but still appear under All Items.

## Market item modes
- Replaced the old simple enabled/disabled state with:
  - BUY_SELL
  - SELL_ONLY
  - DISABLED
- Admin GUI: press F on an item to cycle its mode.
- Sell Only items can be sold into server stock but cannot be bought directly from server stock.
- Player-to-player Auction House and Market Order systems remain independent.
- Legacy `.enabled` values in `market.yml` migrate automatically.

## Add/configure market items
- Added `/marketadmin additem <material> <base-price> [buy_sell|sell_only|disabled]`.
- Added `/marketadmin mode <material> <buy_sell|sell_only|disabled>`.
- Ancient Debris and unsafe/admin-only vanilla materials remain hard-blocked.

## /market permission handling
- Removed Bukkit's command-level permission gate for `/market`.
- Incog-Shop now checks `incogshop.market` itself and prints the exact missing node if access is denied.
