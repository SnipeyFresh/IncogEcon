# Incog-Shop 1.7.1

- Layout editor now supports three screens:
  - Categories
  - Subcategories
  - Item Browser
- Subcategory button positions are persistent and shared across built-in category submenus.
- All 36 market item display positions are customizable.
- Item browser control buttons (previous/back/search/clear/status/orders/section/page/next) are customizable.
- `/marketadmin layout [categories|subcategories|items]` opens a specific editor.
- Added admin-only Auction House permanent-listing mode.
- Admins see a toggle in `/ah`.
- While enabled, newly created Auction House listings have no expiry time.
- Permanent listings stay active until sold or manually cancelled.
- Permanent listing state is visibly marked as `Expires: Never`.
